var searchData=
[
  ['deccopies_18',['decCopies',['../class_book.html#a42a76eddfaa969d05dbe47f8588ccbcf',1,'Book']]]
];
