var searchData=
[
  ['nocopiesavailable_120',['NoCopiesAvailable',['../class_no_copies_available.html',1,'']]]
];
