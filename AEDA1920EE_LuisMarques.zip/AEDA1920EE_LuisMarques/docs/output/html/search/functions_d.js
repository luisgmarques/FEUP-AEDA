var searchData=
[
  ['sequentialsearch_179',['sequentialSearch',['../group___template.html#gacd555ad1f1fc3b2011aab63641f98151',1,'Search.h']]],
  ['sequentialsearchnopointer_180',['sequentialSearchNoPointer',['../group___template.html#gada542f6ca0126d949ac4f038116a57dd',1,'Search.h']]],
  ['setaddress_181',['setAddress',['../class_reader.html#a1a0d3cf8d63ed5a2eeb04d6b38369297',1,'Reader']]],
  ['setauthors_182',['setAuthors',['../class_book.html#a149b3d40d187d49f998c017b253afb36',1,'Book']]],
  ['setdate_183',['setDate',['../class_reader.html#a1ada909432ca48c2a73257594f971f0a',1,'Reader']]],
  ['setemail_184',['setEmail',['../class_reader.html#ab1fdb31654d34dabaf691e7417ec57b8',1,'Reader']]],
  ['setemployees_185',['setEmployees',['../class_employee.html#ab589e00144c5aa2eceb200b53a5656ba',1,'Employee::setEmployees()'],['../class_supervisor.html#ad1cc0f1a083ad03267c6b4bb09645350',1,'Supervisor::setEmployees()']]],
  ['setname_186',['setName',['../class_employee.html#a3ff492bd2eb493d2e7c94d41bd8fa394',1,'Employee::setName()'],['../class_reader.html#a8540f3fa7b376011b3ec4b795016ea63',1,'Reader::setName()']]],
  ['setpages_187',['setPages',['../class_book.html#afba63ff65bc4614e5d0996b868474b92',1,'Book']]],
  ['setpassword_188',['setPassword',['../class_employee.html#a6056a6c3a5c66c1b0d854231709b3816',1,'Employee']]],
  ['setphone_189',['setPhone',['../class_reader.html#a16f6ed21d9ff0de82b443176199a5a53',1,'Reader']]],
  ['setrequests_190',['setRequests',['../class_book.html#a29c05c216084ca82ab66006fdbd3d567',1,'Book']]],
  ['settitle_191',['setTitle',['../class_book.html#a016835198c8f7884542f12307a2ae64e',1,'Book']]],
  ['settotalcopies_192',['setTotalCopies',['../class_book.html#a5cab0e8a9472f8f1e207d95e3232493c',1,'Book']]],
  ['setyear_193',['setYear',['../class_book.html#afe4e839a0539c83dae090cd5ed8f853e',1,'Book']]],
  ['supervisor_194',['Supervisor',['../class_supervisor.html#ab0e6ed69ee02ff3eae8ac81e303bb58e',1,'Supervisor::Supervisor(const string &amp;name, string pass, vector&lt; Employee * &gt; employees, Position pos=Sup)'],['../class_supervisor.html#ad3c41c521fa89c7a013b99eb65051a31',1,'Supervisor::Supervisor(int id, const string &amp;name, string pass, vector&lt; Employee * &gt; employees, Position pos=Sup)']]]
];
