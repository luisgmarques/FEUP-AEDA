var searchData=
[
  ['pages_208',['pages',['../class_book.html#af4911f9ba822e0c95ab759f30077539b',1,'Book']]]
];
