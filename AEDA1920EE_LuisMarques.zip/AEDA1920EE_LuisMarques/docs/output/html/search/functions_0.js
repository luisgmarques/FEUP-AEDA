var searchData=
[
  ['addborrow_125',['addBorrow',['../class_reader.html#a3cd9302e5981eb3c19697e86904a05f8',1,'Reader']]],
  ['addemployee_126',['addEmployee',['../class_employee.html#aa298dd608aff8609f1ae939d056af798',1,'Employee::addEmployee()'],['../class_supervisor.html#a8561ea77ed28f8b49442c3b9e9a99cc0',1,'Supervisor::addEmployee()']]],
  ['addrequest_127',['addRequest',['../class_book.html#a2b7fb8304ebcfb97e457699cbaabef93',1,'Book']]],
  ['admin_128',['Admin',['../class_admin.html#ac21545a6a9437e13211ae633dae0fd0d',1,'Admin']]],
  ['app_129',['App',['../class_app.html#a838e4582e6f3c53134c1529bed5197fc',1,'App']]]
];
