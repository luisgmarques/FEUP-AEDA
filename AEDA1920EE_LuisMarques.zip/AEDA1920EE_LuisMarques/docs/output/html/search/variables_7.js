var searchData=
[
  ['title_210',['title',['../class_book.html#a694d90d6902d5f9d280db89ba533fad6',1,'Book']]],
  ['total_5fcopies_211',['total_copies',['../class_book.html#a612e491b8c02d324ac45832881699918',1,'Book']]],
  ['total_5fdifferent_5fbooks_212',['total_different_books',['../class_book.html#a9cb720942d2bbcc1b134cb9cae2824d5',1,'Book']]]
];
