var searchData=
[
  ['last_5fid_55',['last_id',['../class_book.html#ad188fabaa4fb4aef286b4f991870592e',1,'Book']]],
  ['library_56',['Library',['../class_library.html',1,'Library'],['../class_app.html#a74d3c55bc09672b60b31218844196420',1,'App::library()'],['../class_library.html#adf6eb143b82118944c6f52f4705754bc',1,'Library::Library()']]]
];
