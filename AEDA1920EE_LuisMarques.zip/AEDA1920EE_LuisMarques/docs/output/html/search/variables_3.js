var searchData=
[
  ['last_5fid_205',['last_id',['../class_book.html#ad188fabaa4fb4aef286b4f991870592e',1,'Book']]],
  ['library_206',['library',['../class_app.html#a74d3c55bc09672b60b31218844196420',1,'App']]]
];
