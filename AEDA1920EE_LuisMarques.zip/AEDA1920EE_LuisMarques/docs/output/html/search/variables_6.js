var searchData=
[
  ['requests_209',['requests',['../class_book.html#ae1d2f1fe91585a7ee3e9c6494e6526d9',1,'Book']]]
];
