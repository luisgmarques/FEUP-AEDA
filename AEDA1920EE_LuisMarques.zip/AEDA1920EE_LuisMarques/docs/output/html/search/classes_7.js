var searchData=
[
  ['maxborrowslimit_119',['MaxBorrowsLimit',['../class_max_borrows_limit.html',1,'']]]
];
