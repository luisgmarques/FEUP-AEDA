var searchData=
[
  ['nocopiesavailable_59',['NoCopiesAvailable',['../class_no_copies_available.html',1,'NoCopiesAvailable'],['../class_no_copies_available.html#a35db79d9143afe3c2e5c7c8836411cb5',1,'NoCopiesAvailable::NoCopiesAvailable()']]]
];
