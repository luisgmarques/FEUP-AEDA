var searchData=
[
  ['objectnotfound_60',['ObjectNotFound',['../class_object_not_found.html',1,'ObjectNotFound'],['../class_object_not_found.html#ac9ac4ad43e75acb850baca45801de2c5',1,'ObjectNotFound::ObjectNotFound()']]],
  ['operator_3c_61',['operator&lt;',['../class_book.html#a49093682e197d1e07a5adb9c3c5bd0fa',1,'Book::operator&lt;()'],['../class_borrow.html#aca7cba1011fba36c9cc6b6983fe5845c',1,'Borrow::operator&lt;()'],['../class_request.html#aae03a366b87ac07165dba0503889c7e6',1,'Request::operator&lt;()']]],
  ['operator_3c_3c_62',['operator&lt;&lt;',['../class_file_unkown.html#abb9a73a583499d82dece29e9e2bc4d58',1,'FileUnkown::operator&lt;&lt;()'],['../class_object_not_found.html#a95e3ec9154ddf3855e33fd7153ee3575',1,'ObjectNotFound::operator&lt;&lt;()'],['../class_max_borrows_limit.html#a7885d1fce94583b87502341904e8b40e',1,'MaxBorrowsLimit::operator&lt;&lt;()'],['../class_no_copies_available.html#a6fdb710f25f5d55d5b486df11f87830a',1,'NoCopiesAvailable::operator&lt;&lt;()'],['../class_borrows_to_delivered.html#ae7e1c0bb88c9f5db98fcfaa2cf6f8f64',1,'BorrowsToDelivered::operator&lt;&lt;()']]],
  ['orderbyyear_63',['orderByYear',['../class_library.html#ae7cc454b93e04c368b2ac34bbaf84b94',1,'Library']]]
];
