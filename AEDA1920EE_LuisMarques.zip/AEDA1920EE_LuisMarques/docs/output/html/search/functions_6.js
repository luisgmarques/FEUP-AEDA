var searchData=
[
  ['inccopies_162',['incCopies',['../class_book.html#ae4313a04f1a5683538e2193870735063',1,'Book']]],
  ['insertionsort_163',['insertionSort',['../group___template.html#ga2d750432a373f9dab8039bef160b71a0',1,'Sort.h']]]
];
