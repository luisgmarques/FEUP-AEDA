var searchData=
[
  ['year_100',['year',['../class_book.html#a62717bd851774f8bcb7781a1ab55c4c2',1,'Book']]]
];
