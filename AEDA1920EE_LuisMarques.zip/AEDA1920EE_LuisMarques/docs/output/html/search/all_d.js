var searchData=
[
  ['reader_70',['Reader',['../class_reader.html',1,'Reader'],['../class_reader.html#a09e420e15a384f05f63bab029537da55',1,'Reader::Reader(const string &amp;name, int phone_number, const string &amp;email, string address, int type, vector&lt; Borrow * &gt; books)'],['../class_reader.html#ab6fe78ab6fae09510d5b0824c4f227a9',1,'Reader::Reader(int id, const string &amp;name, int phone_number, const string &amp;email, string address, int type, time_t date, vector&lt; Borrow * &gt; books)']]],
  ['removeborrow_71',['removeBorrow',['../class_reader.html#a6526400cf184348a6f1a18c4748a14a8',1,'Reader']]],
  ['removerequest_72',['removeRequest',['../class_book.html#aecf279741d647d62e741d72ac40cfc65',1,'Book']]],
  ['request_73',['Request',['../class_request.html',1,'Request'],['../class_request.html#a49e963046e93e91ffa17448533e22f7c',1,'Request::Request(int id, Book *book, Employee *employee, Reader *reader, time_t date)'],['../class_request.html#aebb4b28777932af175cee578774e08a9',1,'Request::Request(Book *book, Employee *employee, Reader *reader, time_t date)']]],
  ['requests_74',['requests',['../class_book.html#ae1d2f1fe91585a7ee3e9c6494e6526d9',1,'Book']]]
];
