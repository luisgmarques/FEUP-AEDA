var searchData=
[
  ['orderbyyear_207',['orderByYear',['../class_library.html#ae7cc454b93e04c368b2ac34bbaf84b94',1,'Library']]]
];
