var indexSectionsWithContent =
{
  0: "abdefghilmnoprstuwy",
  1: "abefhilmnors",
  2: "abdefgilmnoprsw",
  3: "aeiloprtuy",
  4: "o",
  5: "f",
  6: "f"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "related",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Friends",
  5: "Modules",
  6: "Pages"
};

