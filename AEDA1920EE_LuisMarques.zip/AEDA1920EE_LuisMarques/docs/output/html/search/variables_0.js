var searchData=
[
  ['authors_200',['authors',['../class_book.html#ab2bc06e04240ad81300d31fca7c25169',1,'Book']]],
  ['available_5fcopies_201',['available_copies',['../class_book.html#a90bc0956856ce93d636402785852ba34',1,'Book']]]
];
