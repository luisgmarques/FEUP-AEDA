var searchData=
[
  ['binarynode_7',['BinaryNode',['../class_binary_node.html',1,'']]],
  ['binarynode_3c_20book_20_3e_8',['BinaryNode&lt; Book &gt;',['../class_binary_node.html',1,'']]],
  ['book_9',['Book',['../class_book.html',1,'Book'],['../class_book.html#af84785d94b84ef4f8ac7dcc0ee251f15',1,'Book::Book(string title, string isbn, vector&lt; string &gt; authors, int pages, int year, int total_copies=0)'],['../class_book.html#a73ee9220070149b00b1d58ab96fde7ac',1,'Book::Book(int id, string title, string isbn, vector&lt; string &gt; authors, int pages, int year, int total_copies=0)'],['../class_book.html#aca3fd58bad5fd8ec5f3e1b519494e2cf',1,'Book::Book(string title, string isbn, string authors, int pages, int year, int total_copies=0)']]],
  ['borrow_10',['Borrow',['../class_borrow.html',1,'Borrow'],['../class_borrow.html#a042bd6e014e65674790ac6a3a4bdfd1f',1,'Borrow::Borrow(int id, Book *book, Reader *reader, Employee *employee, time_t date)'],['../class_borrow.html#a22f34d8880ad5b86a66b802c2902dcc7',1,'Borrow::Borrow(Book *book, Reader *reader, Employee *employee, time_t date)']]],
  ['borrowstodelivered_11',['BorrowsToDelivered',['../class_borrows_to_delivered.html',1,'BorrowsToDelivered'],['../class_borrows_to_delivered.html#a57e18bf0f28dc95ce2f3fc4674026fd3',1,'BorrowsToDelivered::BorrowsToDelivered()']]],
  ['bst_12',['BST',['../class_b_s_t.html',1,'']]],
  ['bst_3c_20book_20_3e_13',['BST&lt; Book &gt;',['../class_b_s_t.html',1,'']]],
  ['bstitrin_14',['BSTItrIn',['../class_b_s_t_itr_in.html',1,'']]],
  ['bstitrlevel_15',['BSTItrLevel',['../class_b_s_t_itr_level.html',1,'']]],
  ['bstitrpost_16',['BSTItrPost',['../class_b_s_t_itr_post.html',1,'']]],
  ['bstitrpre_17',['BSTItrPre',['../class_b_s_t_itr_pre.html',1,'']]]
];
